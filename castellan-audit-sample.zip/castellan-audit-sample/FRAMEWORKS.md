# Framework Reference — Castellan Audit Report

Castellan maps every governance policy and audit finding to controls across five compliance frameworks simultaneously. This page explains what each framework is and how Castellan addresses it.

---

## AIUC-1 — AI Use Case Certification

AIUC-1 is a certification framework for AI agent deployments organized around six principles: Security, Safety, Reliability, Accountability, Data & Privacy, and Societal Impact. It requires periodic re-evaluation (quarterly) and evidence of attack resistance testing. Castellan maps compiled policies to 30 sub-controls across all six principles and auto-generates findings when coverage drops below 50%. The attestation block enforces the quarterly re-evaluation cadence as a first-class field.

## ISO/IEC 42001:2023 — AI Management System

ISO 42001 is the international standard for AI management systems, modeled on ISO 27001. It defines 42 Annex A controls covering risk assessment, system development, data governance, testing, transparency, human oversight, and continual improvement. Castellan auto-generates the Statement of Applicability required by Clause 6.1.3, mapping each control to the policies that satisfy it and flagging gaps with justification. This is typically a weeks-long manual exercise — Castellan produces it from compiled policy data in seconds.

## NIST AI RMF 1.0 — AI Risk Management Framework

The NIST AI Risk Management Framework organizes AI risk management into four functions: Govern (policies and accountability), Map (context and categorization), Measure (testing and monitoring), and Manage (risk treatment and response). Castellan maps to 72 subcategories across 19 categories. Governance policies map primarily to Govern and Manage functions; security audit results map to Measure; monitoring data maps to Manage. The framework map enables organizations pursuing NIST AI RMF alignment to trace their Castellan deployment directly to RMF requirements.

## OWASP LLM Top 10 (2025 Edition)

The OWASP LLM Top 10 identifies the ten most critical security risks in large language model applications: Prompt Injection, Sensitive Information Disclosure, Supply Chain Vulnerabilities, Data and Model Poisoning, Improper Output Handling, Excessive Agency, System Prompt Leakage, Vector and Embedding Weaknesses, Misinformation, and Unbounded Consumption. Castellan's Aegis security module tests against all ten vectors. The audit report renders pass/fail/partial status for each vector and auto-generates critical findings for any vector that fails. This gives security teams a single view of their LLM attack surface.

## MITRE ATLAS — Adversarial Threat Landscape for AI Systems

MITRE ATLAS catalogs adversarial techniques against machine learning systems, organized by tactic (Reconnaissance through Impact). Castellan maps 38 techniques across 11 tactics, covering LLM-specific attacks like Prompt Injection (AML.T0051), Jailbreak (AML.T0055), Meta Prompt Extraction (AML.T0054), and Data Leakage (AML.T0059). The audit report shows which techniques have been tested and which mitigations are confirmed, giving red teams and auditors a clear picture of adversarial coverage.

---

## How Mapping Works

Castellan policies declare their framework control references at compile time (e.g., `["AIUC-1:Safety:2.1", "ISO42001:A.6.1"]`). The framework mapper enriches these references with control names, descriptions, and cross-references from the five JSON map files. The Statement of Applicability and coverage tables are generated from this mapping — no manual assembly required.

The framework map files are included in this repository under `framework_maps/` for reference.
